# wcs 1.1 can't run with wcs 2.0 active
rm $1/webapps/geoserver/WEB-INF/lib/*wcs2_0-*.jar
rm $1/webapps/geoserver/WEB-INF/lib/*web-wcs-*.jar
